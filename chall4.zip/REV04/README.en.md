# Ring Zero Whisper

> Challenge ID: `REV-02` · Category: Reverse Engineering · Target solve time: 180-240 phút

## Scenario

A legitimate monitoring loader installs several eBPF programs. Soon after, the content of some SSH sessions appears in DNS traffic. Not every command is logged — only those matching a specific criteria set.

Determine the command-selection rule, recover the exfiltrated data, and prove the full operation chain.

## Provided files

- `loader`
- `programs.bpf`
- `vmlinux.btf`
- `bpftool.json`
- `ringbuf.dump`
- `dns.pcapng`
- `flag.enc`
- `verify.py`
- `FORMAT.md`

## Submission

`verify.py --proof proof.json --payload recovered.bin`

## Hints

- T+100′: Don't analyze each program in isolation — build the chain-graph across tail calls.
- T+170′: Some DNS fragments are lost but can be recovered.
